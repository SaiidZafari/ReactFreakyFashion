 export const products = [
   {
     id: 1,
     title: "Red Fashion",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "999",
     pageName: "Naeim Jafari",
     imageUrl: process.env.PUBLIC_URL + "Naeim-Jafari.jpg",
   },
   {
     id: 2,
     title: "White T-shirt",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "369",
     pageName: "Christian Bold",
     imageUrl: process.env.PUBLIC_URL + "Christian-Bolt.jpg",
   },
   {
     id: 3,
     title: "Winter Coat",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "1500",
     pageName: "Freestocks",
     imageUrl: process.env.PUBLIC_URL + "Freestocks.jpg",
   },
   {
     id: 4,
     title: "Blue Shirt",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "999",
     pageName: "Khosravi",
     imageUrl: process.env.PUBLIC_URL + "Khosravi.jpg",
   },
   {
     id: 5,
     title: "Dog",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "1200",
     pageName: "Dog",
     imageUrl: process.env.PUBLIC_URL + "Dog.jpg",
   },
   {
     id: 6,
     title: "Hand",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "499",
     pageName: "Hand",
     imageUrl: process.env.PUBLIC_URL + "Hand.jpg",
   },
   {
     id: 7,
     title: "Heart",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "456",
     pageName: "Heart",
     imageUrl: process.env.PUBLIC_URL + "Heart.jpg",
   },
   {
     id: 8,
     title: "Mountain",
     description:
       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
     price: "399",
     pageName: "Mountain",
     imageUrl: process.env.PUBLIC_URL + "Mountain.jpg",
   },
 ];