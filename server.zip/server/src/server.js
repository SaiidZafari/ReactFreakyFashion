const express = require("express");
const app = express();

//const cors = require ("cors");
app.use(express.json());


const products = [
  {
    id: 1,
    title: "Red Fashion",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "999",
    pageName: "Naeim-Jafari",
    imageUrl: "Naeim-Jafari.jpg",
    urlSlug: "Naeim-Jafari",
  },
  {
    id: 2,
    title: "White T-shirt",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "369",
    pageName: "Christian-Bold",
    imageUrl: "Christian-Bolt.jpg",
    urlSlug: "Christian-Bold",
  },
  {
    id: 3,
    title: "Winter Coat",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "1500",
    pageName: "Freestocks",
    imageUrl: "Freestocks.jpg",
    urlSlug: "Freestocks",
  },
  {
    id: 4,
    title: "Blue Shirt",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "999",
    pageName: "Khosravi",
    imageUrl: "Khosravi.jpg",
    urlSlug: "Khosravi",
  },
  {
    id: 5,
    title: "Dog",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "1200",
    pageName: "Dog",
    imageUrl: "Dog.jpg",
    urlSlug: "Dog",
  },
  {
    id: 6,
    title: "Hand",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "499",
    pageName: "Hand",
    imageUrl: "Hand.jpg",
    urlSlug: "Hand",
  },
  {
    id: 7,
    title: "Heart",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "456",
    pageName: "Heart",
    imageUrl: "Heart.jpg",
    urlSlug: "Heart",
  },
  {
    id: 8,
    title: "Mountain",
    description:
      "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
    price: "399",
    pageName: "Mountain",
    imageUrl: "Mountain.jpg",
    urlSlug: "Mountain",
  },
];

const heros = [
  {
    id: 1,
    titleH: "Fashion festival",
    descriptionH: `Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ... May 1, 2020 - Explore Roadkill Girl's board "Freaky Fashion", followed by 276 people on Pinterest. See more ideas about fashion, weird fashion, how to wear it.`,
    imageUrlH: "Woman.jpg",
    altH: "Woman",
    buttonTextH: "To Production",
    urlSlug: "Woman",
  },
  {
    id: 2,
    titleH: "Freaky Fashion festival",
    descriptionH: `Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ... May 1, 2020 - Explore Roadkill Girl's board "Freaky Fashion", followed by 276 people on Pinterest. See more ideas about fashion, weird fashion, how to wear it.`,
    imageUrlH: "Heart.jpg",
    altH: "Heart",
    buttonTextH: "To Fashion Section",
    urlSlug: "Heart",
  },
];

const spots = [
  {
    id: 1,
    imageUrl: "hand.jpg",
    spotsTitle: "Beast and beauty",
    titlePosition: "50%",
    linkTo: "Hand",
  },
  {
    id: 2,
    imageUrl: "Mountain.jpg",
    spotsTitle: "Beautiful mountains",
    titlePosition: "50%",
    linkTo: "Mountain",
  },
  {
    id: 3,
    imageUrl: "Heart.jpg",
    spotsTitle: "Capture a moment",
    titlePosition: "50%",
    linkTo: "Heart",
  },
];
 


// const customerBuy = [
//   {
//     id: 8,
//     title: "Mountain",
//     description:
//       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
//     price: "399",
//     pageName: "Mountain",
//     imageUrl: "Mountain.jpg",
//     urlSlug: "Mountain",
//   },
//   {
//     id: 9,
//     title: "Hand",
//     description:
//       "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
//     price: "399",
//     pageName: "Hand",
//     imageUrl: "Hand.jpg",
//     urlSlug: "Hand",
//   },
// ];


// const customerData = [
//   {
//     firstName: "John",
//     lastName: "Doe",
//     email: "john@doe.dk",
//     password: 123,
//     // buy: [customerBuy],
//   },
// ];





app.get("/", (req, res) => {
  res.send("Express Server is running now!");
});

app.get("/api/products", (req, res) => {
  if (!products) res.status(404).send("There is No data in Database.");
  res.send(products);
});

app.get("/api/heros", (req, res) => {
  if (!heros) res.status(404).send("There is No data in Database.");
  res.send(heros);
});

app.get("/api/heros/:urlSlug", (req, res) => {
  const { urlSlug } = req.params;
  const hero = heros.find((x) => x.urlSlug === urlSlug);
  if (!hero)
    res.status(404).send("The hero with given urlSlug wan not found.");
  res.send(hero);
});

app.get("/api/spots", (req, res) => {
  if (!spots) res.status(404).send("There is No data in Database.");
  res.send(spots);
});


app.post("/api/products", (req, res) => {
  const product = {
    id: products.length + 1,
    title: req.body.title,
    description: req.body.description,
    price: req.body.price,
    pageName: req.body.pageName,
    imageUrl: req.body.imageUrl,
    urlSlug: req.body.urlSlug,
  };
  courses.push(product);
  res.send(product);
});
 

app.put("/api/products/:urlSlug", (req, res) => {
  const { urlSlug } = req.params;
  const product = products.find((x) => x.urlSlug === urlSlug);
  if (!product)
    res.status(404).send("The product with given urlSlug wan not found.");
  
  product.title = req.body.title;
  product.description = req.body.description;
  product.price = req.body.price;
  product.pageName = req.body.pageName;
  product.imageUrl = req.body.imageUrl;  
  
   res.send(product);
});
app.get("/api/products/:urlSlug", (req, res) => {
  const { urlSlug } = req.params;
  const product = products.find(x => x.urlSlug === urlSlug);
  if (!product) res.status(404).send('The product with given urlSlug wan not found.');
  res.send(product);
});

app.get("/api/customerData", (req, res) => {
  if (!customerData) res.status(404).send("There is No data in Database.");
  res.send(customerData);
});

// POST /api/applications
app.post('/api/applications', (req, res) => {

    // req.params, req.query, req.body
    const {
        program,
        firstName,
        lastName,
        socialSecurityNumber,
        email,
        phoneNumber
    } = req.body;

    applications.push({
        program,
        firstName,
        lastName,
        socialSecurityNumber,
        email,
        phoneNumber
    });

    res.status(201).send();
});



app.post("/api/customerData", (req, res) => {
   const { firstName, lastName, email, password } = req.body;
  // customerData.push({
  //   title,
  //   description,
  //   price,
  //   pageName,
  //   imageUrl,
  //   urlSlug,
  });
  // const product = {
  //   id: products.length + 1,
  //   title: req.body.title,
  //   description: req.body.description,
  //   price: req.body.price,
  //   pageName: req.body.pageName,
  //   imageUrl: req.body.imageUrl,
  //   urlSlug: req.body.urlSlug,
  // };
  // courses.push(product);
  // res.send(product);
// });

// GET /api/search?q=xxx
app.get('/api/search', (req, res) => {
  const { q } = req.query; 
  console.log(q);
  const regExp = new RegExp(q, 'i');
  const filteredProduct = products.filter((x) => x.title.match(regExp));
  const searchResult = {
    result: filteredProduct,
    count: filteredProduct.length,
  };
  res.json(searchResult);
});

app.post("/api/customerInfo", (req, res) => {
  const {
    firstName,
    lastName,
    email,
    password,
  } = req.body;

  applications.push({
    firstName,
    lastName,
    email,
    password,
  });

  res.status(201).send();
});

// GET /api/applications
app.get("/api/customerInfo", (req, res) => {
  res.json(applications);
});


const port = process.env.port || 4000;

app.listen(port, () =>
  console.log(`listening on http://localhost:${port}`)
);
