const allProducts = {
  Products: [
    {
      id: 1,
      title: "Red Fashion",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "999",
      pageName: "Naeim-Jafari",
      imageUrl: "Naeim-Jafari.jpg",
      urlSlug: "Naeim-Jafari",
    },
    {
      id: 2,
      title: "White T-shirt",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "369",
      pageName: "Christian-Bold",
      imageUrl: "Christian-Bolt.jpg",
      urlSlug: "Christian-Bold",
    },
    {
      id: 3,
      title: "Winter Coat",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "1500",
      pageName: "Freestocks",
      imageUrl: "Freestocks.jpg",
      urlSlug: "Freestocks",
    },
    {
      id: 4,
      title: "Blue Shirt",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "999",
      pageName: "Khosravi",
      imageUrl: "Khosravi.jpg",
      urlSlug: "Khosravi",
    },
    {
      id: 5,
      title: "Dog",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "1200",
      pageName: "Dog",
      imageUrl: "Dog.jpg",
      urlSlug: "Dog",
    },
    {
      id: 6,
      title: "Hand",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "499",
      pageName: "Hand",
      imageUrl: "Hand.jpg",
      urlSlug: "Hand",
    },
    {
      id: 7,
      title: "Heart",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "456",
      pageName: "Heart",
      imageUrl: "Heart.jpg",
      urlSlug: "Heart",
    },
    {
      id: 8,
      title: "Mountain",
      description:
        "Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ...",
      price: "399",
      pageName: "Mountain",
      imageUrl: "Mountain.jpg",
      urlSlug: "Mountain",
    },
  ],

  Heros: [
    {
      id: 1,
      title: "Fashion festival",
      description: `Welcome to Fashion Freak. At, fashion freak, we bring to the industry best fashions in one store. Buy from our wide range of designer T-shirts, shirts, jeans, ... May 1, 2020 - Explore Roadkill Girl's board "Freaky Fashion", followed by 276 people on Pinterest. See more ideas about fashion, weird fashion, how to wear it.`,
      imageUrl: "Woman.jpg",
    },
  ],

  Spots: [
    {
      id: 1,
      title: "Beast and beauty",
      imageUrl: "Hand.jpg",
    },
    {
      id: 2,
      title: "Beautiful mountains",
      imageUrl: "Mountains.jpg",
    },
    {
      id: 3,
      title: "Capture a moment",
      imageUrl: "Heart.jpg",
    },
  ],
};