//const express = require('express');  // RequireJS module-system
import express from "express";  //ES6 module-system
//const cors = require('cors');
import cors from "cors";

const app = express();
const port = 5000;

const programs = [
    {
        id: 1,
        name: "Webbutveckling inom .NET",
        description: "Lär dig bygga webbapplikationer med .NET",
        imageUrl: "https://via.placeholder.com/220x200?text=Webbutveckling+inom+.NET",
        urlSlug: "webbutveckling-inom-net"
    },
    {
        id: 2,
        name: "Frontend-utvecklare",
        description: "Lär dig bygga webbapplikationer med JavaScript",
        imageUrl: "https://via.placeholder.com/220x200?text=Frontend-utvecklare",
        urlSlug: "frontend-utvecklare"
    },
    {
        id: 3,
        name: "Java-utvecklare",
        description: "Lär dig bygga webbapplikationer med Java",
        imageUrl: "https://via.placeholder.com/220x200?text=Java",
        urlSlug: "java-utvecklare"
    },
    {
        id: 4,
        name: "UX",
        description: "Lär dig bygga användarvänliga applikationer",
        imageUrl: "https://via.placeholder.com/220x200?text=UX",
        urlSlug: "ux"
    },
    {
        id: 5,
        name: "DevOps Engineer",
        description: "Lär dig DevOps",
        imageUrl: "https://via.placeholder.com/220x200?text=DevOps",
        urlSlug: "devops"
    },
    {
        id: 6,
        name: "Data Scientist",
        description: "Lär dig data science",
        imageUrl: "https://via.placeholder.com/220x200?text=Data+Scientist",
        urlSlug: "data-scientist"
    }
];

app.use(cors());

// GET /api/programs
app.get('/api/programs', (req, res) => {
    res.json(programs);
});

// GET /api/programs/:urlSlug
app.get('/api/programs/:urlSlug', (req, res) => {
    
    const { urlSlug } = req.params;

    const program = programs.find(x => x.urlSlug == urlSlug);
    
    res.json(program);
});

app.listen(port, () => {
  console.log(`Listening at http://localhost:${port}`);
});